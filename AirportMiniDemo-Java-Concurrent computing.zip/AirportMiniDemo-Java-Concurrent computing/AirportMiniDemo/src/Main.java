import java.util.Random;

public class Main {
    public static void main(String[] args) throws Exception {
        Thread.currentThread().setName("MainThread");

        Runway runway = new Runway();
        FuelTruck truck = new FuelTruck();
        Gate[] gates = { new Gate(1), new Gate(2), new Gate(3) };
        Stats stats = new Stats();
        ATC atc = new ATC(runway, truck, gates, stats);

        Random rnd = new Random();
        int emergencyIndex = rnd.nextInt(6); // exactly one emergency

        Plane[] planes = new Plane[6];
        for (int i = 0; i < planes.length; i++) {
            boolean isEmergency = (i == emergencyIndex);
            int pax = 30 + rnd.nextInt(21); // 30..50
            planes[i] = new Plane("Plane-" + (i + 1), isEmergency, atc, pax);
        }

        for (int i = 0; i < planes.length; i++) {
            planes[i].start();
            Thread.sleep(rnd.nextInt(2001)); // 0–2s stagger
        }
        for (Plane p : planes) p.join();

        atc.stopAcceptingAndJoin();
        truck.shutdownNow();
    }
}
