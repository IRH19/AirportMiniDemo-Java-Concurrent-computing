import java.util.Random;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.locks.ReentrantLock;

public class Gate {
    private final int id;
    private final ReentrantLock dockLock = new ReentrantLock(true);
    private final Random rnd = new Random();

    public Gate(int id) { this.id = id; }
    public int id() { return id; }

    public void dock(String planeId) {
        dockLock.lock();
        EventLog.p("Gate-" + id, planeId + " docked");
    }

    public void processTurnaround(String planeId, int passengers, FuelTruck truck) throws InterruptedException {
        ExecutorService pool = Executors.newFixedThreadPool(3);

        pool.submit(() -> {
            Thread.currentThread().setName("Thread-Gate-" + id + "-Disembark");
            EventLog.p("Gate-" + id, planeId + " disembarking " + passengers + " pax...");
            try { Thread.sleep(400 + rnd.nextInt(300)); } catch (InterruptedException ignored) {}
            EventLog.p("Gate-" + id, planeId + " disembark done");
        });

        pool.submit(() -> {
            Thread.currentThread().setName("Thread-Gate-" + id + "-Cleaning");
            EventLog.p("Gate-" + id, planeId + " cleaning & supplies...");
            try { Thread.sleep(500 + rnd.nextInt(400)); } catch (InterruptedException ignored) {}
            EventLog.p("Gate-" + id, planeId + " cleaning done");
        });

        pool.submit(() -> {
            Thread.currentThread().setName("Thread-Gate-" + id + "-Embark");
            EventLog.p("Gate-" + id, planeId + " embarking " + passengers + " pax...");
            try { Thread.sleep(400 + rnd.nextInt(300)); } catch (InterruptedException ignored) {}
            EventLog.p("Gate-" + id, planeId + " embark done");
        });

        pool.shutdown();
        while (!pool.isTerminated()) Thread.sleep(50);

        Future<?> f = truck.refuel(planeId, 500 + rnd.nextInt(400));
        try { f.get(); } catch (Exception ignored) {}
    }

    public void undock(String planeId) {
        EventLog.p("Gate-" + id, planeId + " undocked");
        dockLock.unlock();
    }
}
