public final class EventLog {
    private EventLog() {}
    public static void p(String role, String msg) {
        System.out.println("[" + Thread.currentThread().getName() + "] " + role + ": " + msg);
    }
}
