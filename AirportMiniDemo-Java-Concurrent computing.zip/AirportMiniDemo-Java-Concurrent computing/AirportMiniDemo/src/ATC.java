import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class ATC {
    private final Runway runway;
    private final FuelTruck fuelTruck;
    private final Gate[] gates;
    private final Semaphore groundSlots = new Semaphore(3, true); // includes runway occupancy
    private final BlockingQueue<Plane> emergencyQ = new LinkedBlockingQueue<>();
    private final BlockingQueue<Plane> normalQ = new LinkedBlockingQueue<>();
    private final BlockingQueue<Gate> freeGates = new LinkedBlockingQueue<>();
    private final Stats stats;

    private final AtomicBoolean accepting = new AtomicBoolean(true);
    private final Thread dispatcher;

    public ATC(Runway runway, FuelTruck truck, Gate[] gates, Stats stats) {
        this.runway = runway; this.fuelTruck = truck; this.gates = gates; this.stats = stats;
        for (Gate g : gates) freeGates.offer(g);
        this.dispatcher = new Thread(this::dispatchLoop, "Thread-ATC");
        this.dispatcher.start();
    }

    public void requestToLand(Plane p) {
        if (p.isEmergency()) emergencyQ.offer(p); else normalQ.offer(p);
    }

    public Gate awaitClearance(Plane p) throws InterruptedException {
        return p.clearanceQueue.take();
    }

    private void dispatchLoop() {
        try {
            while (accepting.get() || !emergencyQ.isEmpty() || !normalQ.isEmpty()) {
                Plane p = emergencyQ.poll(100, TimeUnit.MILLISECONDS);
                if (p == null) p = normalQ.poll(100, TimeUnit.MILLISECONDS);
                if (p == null) continue;

                Gate g = freeGates.take();      // true reservation
                groundSlots.acquire();          // counts runway too

                EventLog.p("ATC", "Cleared " + p.id() + " to land (Gate-" + g.id() + ")");
                p.clearanceQueue.put(g);
            }
        } catch (InterruptedException ignored) {}
    }

    public void landingSequence(Plane p, Gate gate) throws InterruptedException {
        long t0 = System.currentTimeMillis();

        runway.acquire(p.id());
        Thread.sleep(300 + p.rnd.nextInt(300));
        runway.release(p.id());

        gate.dock(p.id());
        stats.recordWait(System.currentTimeMillis() - t0);

        gate.processTurnaround(p.id(), p.passengers(), fuelTruck);

        gate.undock(p.id());

        runway.acquire(p.id());
        Thread.sleep(250 + p.rnd.nextInt(250));
        runway.release(p.id());

        groundSlots.release();
        stats.recordPlaneServed();
        stats.addPassengers(p.passengers());

        freeGates.offer(gate);
    }

    public void stopAcceptingAndJoin() {
        accepting.set(false);
        try { dispatcher.join(); } catch (InterruptedException ignored) {}
        new Thread(() -> {
            Thread.currentThread().setName("Thread-ATC");
            EventLog.p("ATC", "Simulation ended. Gates empty? yes (released back to pool).");
            EventLog.p("ATC", "Stats: " + stats.summary());
        }, "Thread-ATC").start();
        try { Thread.sleep(50); } catch (InterruptedException ignored) {}
    }
}
