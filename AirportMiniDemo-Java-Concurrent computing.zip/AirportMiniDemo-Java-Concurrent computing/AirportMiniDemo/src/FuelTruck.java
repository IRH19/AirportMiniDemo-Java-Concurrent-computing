import java.util.concurrent.*;

public class FuelTruck {
    private final ExecutorService exec = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Thread-FuelTruck");
        t.setDaemon(true);
        return t;
    });

    public Future<?> refuel(String planeId, long ms) {
        return exec.submit(() -> {
            EventLog.p("FuelTruck", planeId + " refuelling...");
            try { Thread.sleep(ms); } catch (InterruptedException ignored) {}
            EventLog.p("FuelTruck", planeId + " refuel done");
        });
    }

    public void shutdownNow() {
        exec.shutdownNow();
    }
}
