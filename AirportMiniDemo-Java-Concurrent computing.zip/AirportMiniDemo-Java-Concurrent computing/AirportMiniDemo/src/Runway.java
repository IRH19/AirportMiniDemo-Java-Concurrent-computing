import java.util.concurrent.Semaphore;

public class Runway {
    private final Semaphore sem = new Semaphore(1, true);
    public void acquire(String planeId) throws InterruptedException {
        EventLog.p("Runway", planeId + " waiting for runway");
        sem.acquire();
        EventLog.p("Runway", planeId + " acquired runway");
    }
    public void release(String planeId) {
        sem.release();
        EventLog.p("Runway", planeId + " released runway");
    }
}
