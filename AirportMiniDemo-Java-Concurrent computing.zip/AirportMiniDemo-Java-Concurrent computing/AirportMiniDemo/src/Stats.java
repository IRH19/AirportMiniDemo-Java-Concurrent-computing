import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

public class Stats {
    private final AtomicInteger planesServed = new AtomicInteger(0);
    private final AtomicInteger passengersBoarded = new AtomicInteger(0);
    private final AtomicLong totalWaitMs = new AtomicLong(0);
    private final AtomicLong minWaitMs = new AtomicLong(Long.MAX_VALUE);
    private final AtomicLong maxWaitMs = new AtomicLong(0);

    public void recordPlaneServed() { planesServed.incrementAndGet(); }
    public void addPassengers(int n) { passengersBoarded.addAndGet(n); }

    public void recordWait(long waitMs) {
        totalWaitMs.addAndGet(waitMs);
        // update min
        while (true) {
            long prev = minWaitMs.get();
            if (waitMs < prev) {
                if (minWaitMs.compareAndSet(prev, waitMs)) break;
            } else break;
        }
        // update max
        while (true) {
            long prev = maxWaitMs.get();
            if (waitMs > prev) {
                if (maxWaitMs.compareAndSet(prev, waitMs)) break;
            } else break;
        }
    }

    public String summary() {
        int n = planesServed.get();
        long avg = (n == 0) ? 0 : totalWaitMs.get() / n;
        long min = (minWaitMs.get() == Long.MAX_VALUE) ? 0 : minWaitMs.get();
        long max = maxWaitMs.get();
        return "Planes served=" + n +
                ", Passengers boarded=" + passengersBoarded.get() +
                ", Wait(ms) [min/avg/max]=[" + min + "/" + avg + "/" + max + "]";
    }
}
