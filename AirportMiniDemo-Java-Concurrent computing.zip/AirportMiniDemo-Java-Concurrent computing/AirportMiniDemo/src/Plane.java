import java.util.Random;
import java.util.concurrent.SynchronousQueue;

public class Plane extends Thread {
    private final String id;
    private final boolean emergency;
    final Random rnd = new Random();
    private final ATC atc;
    private final int passengers;
    final SynchronousQueue<Gate> clearanceQueue = new SynchronousQueue<>();

    public Plane(String id, boolean emergency, ATC atc, int passengers) {
        super("Thread-Plane-" + id.substring(id.indexOf('-') + 1));
        this.id = id;
        this.emergency = emergency;
        this.atc = atc;
        this.passengers = passengers;
    }

    public String id() { return id; }
    public boolean isEmergency() { return emergency; }
    public int passengers() { return passengers; }

    @Override
    public void run() {
        try {
            EventLog.p(id, "Requesting permission to land" + (emergency ? " [EMERGENCY]" : ""));
            atc.requestToLand(this);

            Gate gate = atc.awaitClearance(this);
            EventLog.p(id, "Cleared to land → Gate-" + gate.id());

            atc.landingSequence(this, gate);
            EventLog.p(id, "Completed turnaround and departure");
        } catch (InterruptedException e) {
            EventLog.p(id, "Interrupted");
            Thread.currentThread().interrupt();
        }
    }
}
